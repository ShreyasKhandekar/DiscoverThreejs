
























































import {
  BoxBufferGeometry,
  Color,
  Mesh,
  MeshBasicMaterial,
  PerspectiveCamera,
  Scene,
  WebGLRenderer,
} from 'https://cdn.skypack.dev/three@0.136.2';

// just waiting for your beautiful creations!
